"""Focused tests for the pieces that are new in this project (the structure/FVG/OB engine itself is
carried over unchanged from the earlier, separately-tested apps)."""

from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import pandas as pd
import pytest

from btstruct.bars import AsOfIndex, ticks_to_bars
from btstruct.backtest import run_backtest
from btstruct.models import Candle, Trend
from btstruct.patterns import detect_double_patterns, fractal_swings, last_swing_before
from btstruct.strategy import StrategyConfig
from btstruct.zones import Zone


def mk(rows, step=60, tz="UTC"):
    t0 = pd.Timestamp("2026-01-01", tz=tz)
    return [Candle(t0 + pd.Timedelta(seconds=step * i), o, h, l, c) for i, (o, h, l, c) in enumerate(rows)]


# ------------------------------------------------------------------ bars / as-of (no look-ahead)
def test_ticks_to_bars_and_asof_never_look_ahead():
    ticks = pd.DataFrame({"timestamp": [0, 2000, 4000, 6000, 11000, 13000],
                         "bidPrice": [100, 101, 99, 102, 103, 101],
                         "askPrice": [100.2, 101.2, 99.2, 102.2, 103.2, 101.2]})
    bars = ticks_to_bars(ticks, "5s")
    assert [b.open for b in bars] == [100.1, 102.1, 103.1]
    assert bars[0].high == 101.1 and bars[0].low == 99.1
    ai = AsOfIndex(bars, "5s")
    assert ai.index_asof(pd.Timestamp(4999, unit="ms", tz="UTC")) is None     # bar not closed yet
    assert ai.index_asof(pd.Timestamp(5000, unit="ms", tz="UTC")) == 0        # closes exactly at 5s
    assert ai.index_asof(pd.Timestamp(9999, unit="ms", tz="UTC")) == 0
    assert ai.index_asof(pd.Timestamp(-1, unit="ms", tz="UTC")) is None


# ------------------------------------------------------------------ double top / bottom
DOUBLE_BOTTOM = [(105, 106, 104, 105), (105, 104, 100, 101), (101, 103, 100.5, 102), (102, 108, 101, 107),
                 (107, 110, 106, 108), (108, 105, 101, 102), (102, 103, 100.4, 101), (101, 105, 100.8, 104),
                 (104, 112, 103, 111)]


def test_double_bottom_detected_on_neckline_break():
    cs = mk(DOUBLE_BOTTOM, step=300)
    (sig,) = detect_double_patterns(cs, k=1, tol_atr=0.3, max_bars=10)
    assert sig.kind == "double_bottom" and sig.direction is Trend.BULLISH
    assert (sig.l1_index, sig.l2_index, sig.confirm_index) == (1, 6, 8)
    assert sig.neckline == 110


def test_double_top_is_the_mirror():
    K = 210  # mirror every price around K so a genuine double-TOP series results (not just h/l swapped)
    cs = mk([(K - o, K - l, K - h, K - c) for o, h, l, c in DOUBLE_BOTTOM], step=300)
    (sig,) = detect_double_patterns(cs, k=1, tol_atr=0.3, max_bars=10)
    assert sig.kind == "double_top" and sig.direction is Trend.BEARISH
    assert (sig.l1_index, sig.l2_index, sig.confirm_index) == (1, 6, 8) and sig.neckline == K - 110


def test_second_low_lower_than_first_is_not_a_double_bottom():
    rows = [(105, 106, 104, 105), (105, 104, 95, 96), (96, 103, 95.5, 102), (102, 108, 101, 107),
            (107, 110, 106, 108), (108, 105, 101, 102), (102, 103, 90, 91), (91, 105, 90.8, 104)]
    cs = mk(rows, step=300)
    sigs = [s for s in detect_double_patterns(cs, k=1, tol_atr=0.3, max_bars=10) if s.kind == "double_bottom"]
    assert sigs == []                                     # L2 (90) is far from L1 (95) -> no pattern


def test_no_lookahead_on_patterns_prefix_is_stable():
    cs = mk(DOUBLE_BOTTOM, step=300)
    full = {(s.l1_index, s.l2_index, s.confirm_index) for s in detect_double_patterns(cs, k=1, tol_atr=0.3)}
    prefix = {(s.l1_index, s.l2_index, s.confirm_index) for s in detect_double_patterns(cs[:8], k=1, tol_atr=0.3)}
    assert prefix <= full


def test_fractal_swings_and_last_swing_before():
    cs = mk(DOUBLE_BOTTOM, step=300)
    swings = fractal_swings(cs, k=1)
    assert (1, False, 100) in [(s.index, s.is_high, s.price) for s in swings]
    sw = last_swing_before(cs, 8, want_low=True, k=1)
    assert sw.index == 6 and sw.price == 100.4
    assert last_swing_before(cs, 2, want_low=True, k=1) is None   # not enough history yet


# ------------------------------------------------------------------ zones
def test_zone_active_at_and_overlaps():
    z = Zone("15m", "OB", scope=None, direction=Trend.BULLISH, top=105, bottom=100,
            known_ts=pd.Timestamp("2026-01-01 00:15", tz="UTC"), end_ts=pd.Timestamp("2026-01-01 01:00", tz="UTC"))
    assert not z.active_at(pd.Timestamp("2026-01-01 00:10", tz="UTC"))   # before it existed
    assert z.active_at(pd.Timestamp("2026-01-01 00:30", tz="UTC"))
    assert not z.active_at(pd.Timestamp("2026-01-01 01:00", tz="UTC"))   # invalidated at this instant
    assert z.overlaps(99, 101) and z.overlaps(104, 110) and not z.overlaps(106, 108)
    assert z.distance(102) == 0 and z.distance(90) == 10 and z.distance(120) == -15


# ------------------------------------------------------------------ backtest is deterministic
def test_backtest_is_deterministic_and_internally_consistent():
    from data.synthetic_ticks import generate
    from btstruct.bars import build_all_timeframes
    from btstruct.strategy import ALL_TIMEFRAMES_NEEDED

    ticks = generate("BTCUSD", days=2, seed=3)
    bars = build_all_timeframes(ticks, ALL_TIMEFRAMES_NEEDED)
    cfg = StrategyConfig("15m", "15m", "30s", lower_tier_tf="5m", barrier_tfs=["1h", "4h"])
    r1 = run_backtest("BTCUSD", bars, cfg)
    r2 = run_backtest("BTCUSD", bars, cfg)
    assert [t.__dict__ for t in r1.trades] == [t.__dict__ for t in r2.trades]
    for t in r1.trades:
        assert t.exit_ts > t.entry_ts and t.risk_points > 0
        bull = t.direction == "BUY"
        expected_r = ((t.exit_price - t.entry_price) / t.risk_points if bull
                     else (t.entry_price - t.exit_price) / t.risk_points)
        assert t.r_multiple == pytest.approx(expected_r)
        if t.outcome == "sl":
            assert t.exit_price == pytest.approx(t.sl_price)
        if t.outcome == "tp":
            assert t.exit_price == pytest.approx(t.tp_price)
    # trades for one config never overlap (one at a time)
    for a, b in zip(r1.trades, r1.trades[1:]):
        assert b.entry_ts >= a.exit_ts
