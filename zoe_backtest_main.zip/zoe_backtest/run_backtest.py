#!/usr/bin/env python3
"""CLI: build every required timeframe from a tick CSV and backtest the ZOE strategy.

    python run_backtest.py --ticks btcusd_ticks.csv --symbol BTCUSD --config all --out results/btc

``--ticks`` must be a CSV with columns: timestamp (epoch ms), bidPrice, askPrice[, bidVolume, askVolume].
Both ``fetch_ticks.js`` (real Dukascopy data) and ``synthetic_ticks.py`` (demo data) produce this format.
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import pandas as pd

from btstruct import (ALL_TIMEFRAMES_NEEDED, CONFIGS, build_all_timeframes, equity_curve_png,
                      print_summary, run_backtest, summarize)


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--ticks", required=True, help="tick CSV (see format above)")
    ap.add_argument("--symbol", required=True, help="label only, e.g. BTCUSD or XAUUSD")
    ap.add_argument("--config", default="all", choices=["all", *CONFIGS], help="which trading timeframe to test")
    ap.add_argument("--out", default="results/run", help="output file prefix")
    ap.add_argument("--require-lower-tier-confluence", action="store_true",
                    help="turn on the ambiguous extra filter described in strategy.py point 4")
    ap.add_argument("--min-risk-pct", type=float, default=0.0,
                    help="skip trades whose 5s stop-loss distance is below this %% of entry price "
                         "(guards against one tiny stop dominating the whole result; see strategy.py)")
    args = ap.parse_args()

    print(f"Loading ticks from {args.ticks} ...")
    ticks = pd.read_csv(args.ticks)
    print(f"  {len(ticks):,} ticks, {pd.to_datetime(ticks['timestamp'].iloc[0], unit='ms')} -> "
          f"{pd.to_datetime(ticks['timestamp'].iloc[-1], unit='ms')} (UTC)")

    print(f"Building bars for: {', '.join(ALL_TIMEFRAMES_NEEDED)} ...")
    bars = build_all_timeframes(ticks, ALL_TIMEFRAMES_NEEDED)
    for tf, cs in bars.items():
        print(f"  {tf:>4}: {len(cs):,} candles")
    if bars["5s"] and len(bars["5s"]) < 5000:
        print("  NOTE: not much 5-second history - stop-loss placement and trade counts will be thin. "
              "Fetch/generate a longer tick range for a meaningful result.", file=sys.stderr)

    configs = list(CONFIGS.values()) if args.config == "all" else [CONFIGS[args.config]]
    Path(args.out).parent.mkdir(parents=True, exist_ok=True)
    all_trades, summaries = [], []

    for cfg in configs:
        overrides = {}
        if args.require_lower_tier_confluence:
            overrides["require_lower_tier_confluence"] = True
        if args.min_risk_pct > 0:
            overrides["min_risk_pct"] = args.min_risk_pct
        if overrides:
            cfg = type(cfg)(**{**cfg.__dict__, **overrides})
        result = run_backtest(args.symbol, bars, cfg)
        summary = summarize(args.symbol, cfg.name, result.trades)
        print_summary(summary)
        if result.skipped:
            print(f" Skipped (reasons): {dict(result.skipped)}")
        all_trades.extend(result.trades)
        summaries.append(summary)

    if all_trades:
        trades_df = pd.DataFrame([t.__dict__ for t in all_trades])
        trades_df.to_csv(f"{args.out}_trades.csv", index=False)
        print(f"\nWrote {len(all_trades)} trades -> {args.out}_trades.csv")
        for cfg_name in {t.config for t in all_trades}:
            subset = [t for t in all_trades if t.config == cfg_name]
            equity_curve_png(subset, f"{args.out}_{cfg_name}_equity.png")
        print(f"Equity curve PNG(s) -> {args.out}_<config>_equity.png")

    with open(f"{args.out}_summary.json", "w") as f:
        json.dump([s.as_dict() for s in summaries], f, indent=2, default=str)
    print(f"Summary JSON -> {args.out}_summary.json")


if __name__ == "__main__":
    main()
