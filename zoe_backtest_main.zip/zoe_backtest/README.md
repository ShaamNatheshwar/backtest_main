# ZOE multi-timeframe backtest - BTCUSD / XAUUSD

A backtester for your cascading-timeframe strategy: trade-timeframe OB/FVG zone, a confirmation signal
(MSB or double-top/bottom) on a much smaller timeframe, a higher-timeframe barrier check, and a stop-loss
always built from 5-second structure. Four trading timeframes are supported (5m, 15m, 1h, 4h).

## Read this first

1. **I could not run this on real data.** This sandbox has no outbound internet - the npm registry and
   Dukascopy's servers both return HTTP 403 here, the same way Upstox and Yahoo were blocked in earlier
   builds. Everything below was validated on a **synthetic, clearly-labelled** tick stream
   (`data/synthetic_ticks.py`) purely to prove the code runs correctly end-to-end. **The example numbers
   in this README are not evidence the strategy works.** Run it yourself on real data (`data/fetch_ticks.js`)
   before drawing any conclusion.
2. **6 days of data is nowhere near enough to know if a strategy is profitable.** The demo runs below used
   6 days because that's what a sandboxed synthetic generator can produce in a reasonable time; 20-60
   trades is not a statistically meaningful sample for anything, let alone a strategy with this many
   degrees of freedom. Fetch at least several months of real data before trusting any win rate.
3. **One real finding from testing, not a data issue:** a single BTCUSD trade with a $8.6 stop-loss (price
   ~$99,000) swung to +260R and single-handedly produced almost the entire reported profit for the 1h
   config. A 5-second-chart stop can legitimately be tiny, and when it is, R-multiples explode and the
   whole backtest's "profit factor" becomes one lucky (or unlucky) trade in a trenchcoat. I added an
   optional `--min-risk-pct` guard for this (off by default, since it isn't part of your rules) - see
   the comparison further down. **Treat every headline number with this in mind.**

## How your rules were translated into code (read ``btstruct/strategy.py`` for the full version)

| trade_tf | ZOE (zone of entry) | confirm_tf | barrier_tfs (block if opposing zone nearby) |
|---|---|---|---|
| 5m  | 5m internal/external OB or FVG  | 15s | 15m, 1h, 4h |
| 15m | 15m internal/external OB or FVG | 30s | 1h, 4h |
| 1h  | 1h internal/external OB or FVG  | 1m  | 4h |
| 4h  | 4h internal/external OB or FVG  | 5m  | (none above 4h) |

* **Confirmation** = a body-close market-structure break (MSB) in the trade direction, or a completed
  double-bottom/double-top, on `confirm_tf`. Requiring a body close is what enforces "a clear MSB rather
  than a liquidity hunt" - a wick-only sweep never produces an MSB event.
* **Barrier check** = at the moment of confirmation, every timeframe above trade_tf is scanned for an
  *opposing*, still-open zone within `barrier_atr` (default 2) x ATR of price; if found, the trade is
  skipped. This is your "what if 1h/4h overlaps my 15m zone" question.
* **Stop-loss** = always the most recent confirmed swing low/high on the **5-second** chart before entry,
  plus a small buffer. **Exit** = stop hit, target hit, or a 5-second candle **body** closes back through
  the zone (checked before the hard stop) - whichever comes first.

### Where your own message contradicted itself, and what I did about it
Your example said "my ZOE are 15 min OB/FVG of 15 minutes" (zone = same tier as the trade), but your table
said the 15m row is "affected by 5 min OB/FVG" (one tier below). I kept the zone on the trade's own
timeframe (the explicit statement) and implemented the one-tier-below timeframe as an **optional** extra
confluence filter, **off by default**: `--require-lower-tier-confluence` turns it on (requires an open,
same-direction zone on that lower tier too, at confirmation time).

### Take-profit - you never specified one, so this is pure assumption
Two modes, selectable: `next_zone` (default) - the nearest open opposing zone on trade_tf, capped at 6 ATR,
falling back to a fixed 2R if none exists; or `fixed_rr` - always a fixed reward multiple of the stop
distance. **Change this before trusting any result** - it's the single biggest assumption in the whole
backtest. Edit `StrategyConfig.tp_mode` / `fallback_rr` / `tp_cap_atr` in `btstruct/strategy.py`.

### Other assumptions (all flagged in code, repeated here for visibility)
* One open trade at a time per (instrument, trade_tf) - no pyramiding.
* If a stop and a target are both touched within the same 5-second candle, the stop is assumed to have
  been hit first (we only have 5s bars here, not the underlying ticks, so the true intrabar order is
  unknown - a real tick-by-tick replay would remove this assumption entirely).
* A trade that never hits stop/target/invalidation times out after `max_hold_bars` (default 4,000 5s
  candles, ~5.5h) and exits at market - a safety valve, not part of your rules.
* All timeframes are built directly from ticks and bucketed on UTC clock boundaries (no exchange-session
  anchoring) - simpler than the session-aware 4h anchoring in the earlier charting apps, and reasonable
  for BTCUSD/XAUUSD which trade nearly continuously, but worth knowing about.

## Run it

```bash
pip install pandas numpy matplotlib pytest
python -m pytest tests/ -q                          # 8 tests, no internet needed

# 1. Get real data (on YOUR machine - this sandbox cannot reach Dukascopy)
cd data && npm install dukascopy-node
node fetch_ticks.js --instrument btcusd  --from 2025-06-01 --to 2025-09-01 --out btcusd_ticks.csv
node fetch_ticks.js --instrument xauusd  --from 2025-06-01 --to 2025-09-01 --out xauusd_ticks.csv
cd ..

# 2. Backtest
python run_backtest.py --ticks data/btcusd_ticks.csv --symbol BTCUSD --config all --out results/btc
python run_backtest.py --ticks data/xauusd_ticks.csv --symbol XAUUSD --config all --out results/xau

# try the options that matter most:
python run_backtest.py --ticks data/btcusd_ticks.csv --symbol BTCUSD --config 1h --min-risk-pct 0.05 --out results/btc_1h_guarded
python run_backtest.py --ticks data/btcusd_ticks.csv --symbol BTCUSD --config 15m --require-lower-tier-confluence --out results/btc_15m_strict

# no internet? exercise the pipeline on synthetic data instead:
python data/synthetic_ticks.py --symbol BTCUSD --days 6 --out data/btcusd_ticks.csv
```

Tick data for Bitcoin especially can be tens of millions of rows for a multi-month range -
`fetch_ticks.js` downloads and writes day-by-day so a dropped connection only costs you one day.

## What's actually in `results/` (from the synthetic demo data - see warnings above)

`{btc,xau}_summary.json` / `_trades.csv` / `_<tf>_equity.png` for all 4 configs, plus
`btc_15m_strict_*` (both optional filters on, for comparison). In the unguarded BTCUSD 1h run, 1 of 41
trades produced +260R out of +261R total - that is the "small-stop distortion" described above, left in
deliberately so you can see what it looks like rather than quietly filtering it out.

## Layout

```
btstruct/
  engine.py, fvg.py, ob.py   structure / FVG / OB rules (unchanged from the earlier charting apps)
  patterns.py                NEW: double-top / double-bottom, causal, no look-ahead
  bars.py                    tick -> OHLCV for every timeframe + the "as of" cross-timeframe lookup
  zones.py                   per-timeframe zones with a known/invalidated timestamp (close-time based)
  strategy.py                the rules above as a StrategyConfig, one per trade_tf
  backtest.py                the event loop (confirm_tf candle by candle) + Trade records
  metrics.py                 win rate / profit factor / expectancy / drawdown / equity curve
data/
  fetch_ticks.js              real data, run on your own machine
  synthetic_ticks.py          demo-only data generator (clearly not real)
run_backtest.py               CLI
tests/test_core.py            bars/as-of, double-pattern, zone, and determinism tests
```
