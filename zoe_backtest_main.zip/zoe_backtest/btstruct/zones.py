"""Turns per-timeframe structure + FVG + OB results into a flat, time-stamped list of zones that can be
queried "as of" any moment in the backtest without look-ahead: a zone only exists from the close of the
candle that created it, and (if applicable) stops existing at the close of the candle that filled /
mitigated it."""

from __future__ import annotations

from dataclasses import dataclass
from typing import List, Optional, Sequence

import pandas as pd

from .bars import TIMEFRAME_SECONDS
from .engine import analyze_structure
from .fvg import classify_fvg_scopes, detect_fvgs
from .models import Candle, FVGStatus, OBStatus, Scope, StructureResult, Trend
from .ob import detect_order_blocks


@dataclass(frozen=True)
class Zone:
    tf: str
    kind: str           # "OB" | "FVG"
    scope: Scope
    direction: Trend     # BULLISH = BUY zone, BEARISH = SELL zone
    top: float
    bottom: float
    known_ts: pd.Timestamp     # the zone exists from this instant on (no look-ahead)
    end_ts: Optional[pd.Timestamp]   # filled/mitigated at this instant; None = still open at data end

    @property
    def side(self) -> str:
        return "BUY" if self.direction is Trend.BULLISH else "SELL"

    def active_at(self, ts: pd.Timestamp) -> bool:
        return self.known_ts <= ts and (self.end_ts is None or ts < self.end_ts)

    def overlaps(self, low: float, high: float) -> bool:
        return low <= self.top and high >= self.bottom

    def distance(self, price: float) -> float:
        """Signed distance: 0 = price inside, >0 = zone above price, <0 = zone below price."""
        if self.bottom <= price <= self.top:
            return 0.0
        return self.bottom - price if self.bottom > price else self.top - price


def build_zones(tf: str, candles: Sequence[Candle], structure: Optional[StructureResult] = None) -> List[Zone]:
    """``known_ts``/``end_ts`` use the CLOSE time of the deciding candle (``ts + one bar``), not its open
    time - a zone (or its invalidation) is only real once that candle has actually finished forming."""
    structure = structure or analyze_structure(candles)
    fvgs = classify_fvg_scopes(detect_fvgs(candles), structure.events)
    obs = detect_order_blocks(structure, include_mitigated=True)
    delta = pd.Timedelta(seconds=TIMEFRAME_SECONDS[tf])
    out: List[Zone] = []
    for g in fvgs:
        end = candles[g.filled_index].ts + delta if g.filled_index is not None else None
        out.append(Zone(tf, "FVG", g.scope or Scope.INTERNAL, g.direction, g.top, g.bottom,
                        candles[g.index].ts + delta, end))
    for b in obs:
        end = candles[b.mitigated_index].ts + delta if b.mitigated_index is not None else None
        out.append(Zone(tf, "OB", b.scope, b.direction, b.top, b.bottom, candles[b.break_index].ts + delta, end))
    return sorted(out, key=lambda z: z.known_ts)
