"""Double-top / double-bottom detection on the confirmation timeframe.

Not part of the earlier structure engine, built fresh for this strategy. Causal (no look-ahead): a
swing point is only usable once it is "confirmed" (``k`` candles have formed on both sides of it), and
a pattern is only reported on the candle whose BODY closes past the neckline.

Definition used here (please correct me if this isn't what you meant)
    Double bottom (BUY confirmation)
        1. Two confirmed swing lows L1 (older) and L2 (newer), with L2 within ``tol_atr`` x ATR of L1 -
           "a similar low", not a new lower low (a brief wick undercut of L1 by L2 is still allowed,
           since only the low's *price*, not candle order, is compared).
        2. No swing low between L1 and L2 that is lower than both (otherwise that would be the real L1).
        3. The "neckline" = the highest high between L1 and L2.
        4. Confirmation = a later candle's BODY closes above the neckline, within ``max_bars`` of L2.
    Double top (SELL confirmation) is the exact mirror (two similar swing highs, neckline = lowest low
    between them, confirmation = a body close below the neckline).

A fresh double bottom/top is only reported once per (L1, L2) pair.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import List, Optional, Sequence

from .indicators import atr as atr_series
from .models import Candle, Trend


@dataclass(frozen=True)
class SwingPoint:
    index: int
    is_high: bool
    price: float
    confirmed_at: int    # index at which this swing became knowable (no look-ahead)


@dataclass(frozen=True)
class PatternSignal:
    kind: str             # "double_bottom" | "double_top"
    direction: Trend
    l1_index: int
    l2_index: int
    neckline: float
    confirm_index: int    # the candle whose body close confirmed the pattern


def fractal_swings(candles: Sequence[Candle], k: int = 2) -> List[SwingPoint]:
    """Simple k-candle fractal swing points: candle i is a swing high/low if its high/low is the most
    extreme among the ``k`` candles on each side.  Confirmed (knowable) only ``k`` candles later."""
    n = len(candles)
    out: List[SwingPoint] = []
    for i in range(k, n - k):
        window = candles[i - k : i + k + 1]
        if candles[i].high == max(c.high for c in window) and sum(c.high == candles[i].high for c in window) == 1:
            out.append(SwingPoint(i, True, candles[i].high, i + k))
        if candles[i].low == min(c.low for c in window) and sum(c.low == candles[i].low for c in window) == 1:
            out.append(SwingPoint(i, False, candles[i].low, i + k))
    return sorted(out, key=lambda s: s.confirmed_at)


def detect_double_patterns(candles: Sequence[Candle], *, k: int = 2, tol_atr: float = 0.15,
                           max_bars: int = 60) -> List[PatternSignal]:
    """Scan the whole series once; every signal's ``confirm_index`` is the candle that completed it,
    so a backtest can safely use ``[s for s in signals if s.confirm_index == i]`` at each step."""
    swings = fractal_swings(candles, k)
    atr = atr_series(candles)
    highs = [s for s in swings if s.is_high]
    lows = [s for s in swings if s.is_high is False]
    out: List[PatternSignal] = []
    seen = set()

    def scan(points: List[SwingPoint], is_low: bool) -> None:
        for a in range(len(points)):
            l1 = points[a]
            for b in range(a + 1, len(points)):
                l2 = points[b]
                if (l1.index, l2.index) in seen:
                    continue
                tol = tol_atr * (atr[l2.index] or 1e-9)
                if abs(l2.price - l1.price) > tol:
                    continue
                between = [p for p in points if l1.index < p.index < l2.index]
                if is_low and any(p.price < min(l1.price, l2.price) for p in between):
                    continue
                if not is_low and any(p.price > max(l1.price, l2.price) for p in between):
                    continue
                span = candles[l1.index : l2.index + 1]
                neckline = max(c.high for c in span) if is_low else min(c.low for c in span)
                limit = min(len(candles), l2.confirmed_at + max_bars)
                for j in range(l2.confirmed_at, limit):
                    c = candles[j]
                    if is_low and c.close > neckline:
                        out.append(PatternSignal("double_bottom", Trend.BULLISH, l1.index, l2.index, neckline, j))
                        seen.add((l1.index, l2.index)); break
                    if not is_low and c.close < neckline:
                        out.append(PatternSignal("double_top", Trend.BEARISH, l1.index, l2.index, neckline, j))
                        seen.add((l1.index, l2.index)); break

    scan(lows, True)
    scan(highs, False)
    return sorted(out, key=lambda s: s.confirm_index)


def last_swing_before(candles: Sequence[Candle], before_index: int, *, want_low: bool, k: int = 1,
                      max_lookback: int = 300) -> Optional[SwingPoint]:
    """Most recent CONFIRMED swing low/high strictly before ``before_index`` - used to place a stop-loss
    on the 5-second chart (small, tight fractals: ``k=1`` by default, i.e. plain LL/HH/HL/LH)."""
    start = max(0, before_index - max_lookback)
    cands = fractal_swings(candles[start:before_index + 1], k)
    usable = [s for s in cands if s.is_high != want_low and s.confirmed_at + start < before_index]
    if not usable:
        return None
    best = usable[-1]
    return SwingPoint(best.index + start, best.is_high, best.price, best.confirmed_at + start)
