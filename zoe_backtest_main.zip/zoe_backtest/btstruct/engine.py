"""Pullback-validated market-structure engine (HH/HL/LH/LL, BOS, MSB) - timeframe agnostic.

Same rules used in the earlier Nifty/yfinance structure apps (see docstring logic below); reused here
unchanged because the backtest needs identical, previously-validated structure/BOS/MSB semantics on
every timeframe (confirm_tf, zone_tf=trade_tf, and every barrier timeframe above it).

Rules
    * Break = candle BODY closes beyond a level.  Sweep = wick or body.
    * ANCHOR = the extreme of the current leg; with no pullback yet it keeps moving to new extremes.
    * A pullback starts when a later candle SWEEPS the anchor's opposite side; the pullback candle is
      the most extreme candle since then (not the first sweeper).
    * VALIDATION = a later candle's body closes beyond the anchor -> BOS (internal), anchor/pullback
      become inner HH/HL (or LL/LH), the breaking candle becomes the new anchor.
    * MSB = a body close beyond the last confirmed pullback (the "protected" level): the extreme of the
      finished trend is fixed as an EXTERNAL pivot, the trend flips, and candles after it are replayed.
    * No look-ahead: a pivot's `confirmed_at` is never earlier than the candle that confirms it, even
      across repeated flips.
"""

from __future__ import annotations

from typing import Dict, List, Optional, Sequence, Tuple

from .models import BreakKind, Candle, Pivot, PivotKind, Scope, StructureEvent, StructureResult, Trend


class _State:
    __slots__ = ("direction", "protected", "anchor", "pullback", "start")

    def __init__(self, direction: Trend, protected: int, anchor: int) -> None:
        self.direction = direction
        self.start = protected
        self.protected = protected
        self.anchor = anchor
        self.pullback: Optional[int] = None


class MarketStructureEngine:
    def __init__(self, candles: Sequence[Candle]) -> None:
        self._c = list(candles)
        self._swings: Dict[Tuple[bool, int], int] = {}
        self._state: Optional[_State] = None
        self._pivots: Dict[Tuple[PivotKind, int], Pivot] = {}
        self._events: List[StructureEvent] = []
        self._floor = -1
        self._run_hi = 0
        self._run_lo = 0

    def _hi(self, i: int, d: Trend) -> float:
        c = self._c[i]; return c.high if d is Trend.BULLISH else -c.low

    def _lo(self, i: int, d: Trend) -> float:
        c = self._c[i]; return c.low if d is Trend.BULLISH else -c.high

    def _cl(self, i: int, d: Trend) -> float:
        c = self._c[i]; return c.close if d is Trend.BULLISH else -c.close

    def run(self) -> StructureResult:
        for i in range(len(self._c)):
            if self._state is None:
                self._bootstrap(i)
            else:
                self._step(i)

        external: List[Pivot] = []
        last_hi = last_lo = None
        for (is_high, idx), conf in sorted(self._swings.items(), key=lambda kv: kv[0][1]):
            c = self._c[idx]
            if is_high:
                kind = PivotKind.HH if last_hi is None or c.high > last_hi else PivotKind.LH
                last_hi = c.high
            else:
                kind = PivotKind.LL if last_lo is None or c.low < last_lo else PivotKind.HL
                last_lo = c.low
            external.append(Pivot(kind, idx, c.high if is_high else c.low, conf, Scope.EXTERNAL))

        ext_idx = {p.index for p in external}
        internal = [p for p in self._pivots.values() if p.index not in ext_idx]
        result = StructureResult(
            candles=self._c,
            pivots=sorted(external + internal, key=lambda p: (p.index, p.confirmed_at)),
            events=sorted(self._events, key=lambda e: (e.index, e.origin_index)),
        )
        st = self._state
        if st is not None:
            result.trend = st.direction
            result.protected_index = st.protected
            pc = self._c[st.protected]
            result.protected_level = pc.low if st.direction is Trend.BULLISH else pc.high
        return result

    def _bootstrap(self, i: int) -> None:
        if i == 0:
            return
        c = self._c[i]
        hi_c, lo_c = self._c[self._run_hi], self._c[self._run_lo]
        if c.close > hi_c.high:
            self._start(Trend.BULLISH, swing=self._run_lo, upto=i)
        elif c.close < lo_c.low:
            self._start(Trend.BEARISH, swing=self._run_hi, upto=i)
        else:
            if c.high > hi_c.high:
                self._run_hi = i
            if c.low < lo_c.low:
                self._run_lo = i

    def _start(self, direction: Trend, swing: int, upto: int) -> None:
        self._state = _State(direction, protected=swing, anchor=swing + 1)
        prev_floor, self._floor = self._floor, max(self._floor, upto)
        try:
            for j in range(swing + 2, upto + 1):
                self._step(j)
        finally:
            self._floor = prev_floor

    def _step(self, i: int) -> None:
        st = self._state; d = st.direction
        if self._cl(i, d) < self._lo(st.protected, d):
            self._flip(i); return
        a = st.anchor
        if st.pullback is None:
            if self._hi(i, d) > self._hi(a, d):
                st.anchor = i
            elif self._lo(i, d) < self._lo(a, d):
                st.pullback = i
            return
        if self._lo(i, d) < self._lo(st.pullback, d):
            st.pullback = i
        if self._cl(i, d) > self._hi(a, d):
            self._confirm(i, st)

    def _confirm(self, i: int, st: _State) -> None:
        d = st.direction; bull = d is Trend.BULLISH
        self._add_pivot(PivotKind.HH if bull else PivotKind.LL, st.anchor, i)
        self._add_pivot(PivotKind.HL if bull else PivotKind.LH, st.pullback, i)
        a = self._c[st.anchor]
        self._events.append(StructureEvent(BreakKind.BOS, d, a.high if bull else a.low, st.anchor, i,
                                           Scope.INTERNAL, swing_index=st.pullback))
        st.protected, st.anchor, st.pullback = st.pullback, i, None

    def _flip(self, i: int) -> None:
        st = self._state; old = st.direction
        swing = st.anchor
        for j in range(st.start + 1, i):
            if self._hi(j, old) > self._hi(swing, old):
                swing = j
        self._swings.setdefault((old is Trend.BULLISH, swing), max(i, self._floor))
        p = self._c[st.protected]
        self._events.append(StructureEvent(BreakKind.MSB, old.opposite,
                                           p.low if old is Trend.BULLISH else p.high,
                                           st.protected, i, Scope.EXTERNAL, swing_index=swing))
        self._start(old.opposite, swing=swing, upto=i)

    def _add_pivot(self, kind: PivotKind, index: int, confirmed_at: int) -> None:
        c = self._c[index]
        price = c.high if kind.is_high else c.low
        self._pivots.setdefault((kind, index), Pivot(kind, index, price, max(confirmed_at, self._floor), Scope.INTERNAL))


def analyze_structure(candles: Sequence[Candle]) -> StructureResult:
    return MarketStructureEngine(candles).run()
