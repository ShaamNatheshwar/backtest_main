"""Tick -> OHLCV bar construction, and a tiny "as-of" index helper used to cross-reference timeframes
without look-ahead (every lookup finds the last candle that had CLOSED by a given timestamp)."""

from __future__ import annotations

from bisect import bisect_right
from typing import Dict, List, Optional, Sequence

import pandas as pd

from .models import Candle

# Every timeframe used anywhere in the strategy (confirmation, zone, barrier and stop-loss timeframes).
TIMEFRAME_SECONDS: Dict[str, int] = {
    "5s": 5, "15s": 15, "30s": 30, "1m": 60, "5m": 300, "15m": 900, "1h": 3600, "4h": 14400,
}


def ticks_to_bars(ticks: pd.DataFrame, timeframe: str, *, price_col: str = "mid") -> List[Candle]:
    """``ticks`` must have a tz-aware DatetimeIndex (or a 'timestamp' column) and bid/ask columns, or
    a pre-computed ``price_col``. Bars are anchored to UTC midnight (a simplification - real exchange
    sessions are not modelled here; see README)."""
    secs = TIMEFRAME_SECONDS[timeframe]
    df = ticks.copy()
    if "timestamp" in df.columns and not isinstance(df.index, pd.DatetimeIndex):
        df = df.set_index(pd.DatetimeIndex(pd.to_datetime(df["timestamp"], unit="ms", utc=True)))
    if df.index.tz is None:
        df.index = df.index.tz_localize("UTC")
    if price_col not in df.columns:
        df[price_col] = (df["bidPrice"] + df["askPrice"]) / 2.0 if "askPrice" in df.columns else df["bidPrice"]
    if "volume" not in df.columns:
        bidv = df["bidVolume"] if "bidVolume" in df.columns else pd.Series(0.0, index=df.index)
        askv = df["askVolume"] if "askVolume" in df.columns else pd.Series(0.0, index=df.index)
        df["volume"] = bidv.fillna(0) + askv.fillna(0)

    bucket = df.index.floor(f"{secs}s")
    g = df.groupby(bucket)
    o = g[price_col].first(); h = g[price_col].max(); l = g[price_col].min(); c = g[price_col].last()
    v = g["volume"].sum()
    return [Candle(ts, float(o[ts]), float(h[ts]), float(l[ts]), float(c[ts]), float(v[ts])) for ts in o.index]


def bars_to_bars(base: Sequence[Candle], timeframe: str, base_seconds: int) -> List[Candle]:
    """Aggregate already-built bars into a coarser timeframe (faster than rebuilding from raw ticks)."""
    secs = TIMEFRAME_SECONDS[timeframe]
    assert secs % base_seconds == 0, f"{timeframe} is not a multiple of the base {base_seconds}s bars"
    factor = secs // base_seconds
    out: List[Candle] = []
    for i in range(0, len(base) - len(base) % factor if len(base) % factor else len(base), factor):
        chunk = base[i : i + factor]
        if not chunk:
            continue
        out.append(Candle(chunk[0].ts, chunk[0].open, max(c.high for c in chunk), min(c.low for c in chunk),
                          chunk[-1].close, sum(c.volume for c in chunk)))
    return out


def build_all_timeframes(ticks: pd.DataFrame, timeframes: Sequence[str]) -> Dict[str, List[Candle]]:
    """Build every requested timeframe directly from ticks (correct, simple; fine for backtest-scale data)."""
    return {tf: ticks_to_bars(ticks, tf) for tf in timeframes}


class AsOfIndex:
    """Given a sorted candle list, find the index of the last candle whose CLOSE time is <= a timestamp -
    i.e. "what did this timeframe look like at this exact moment", with no look-ahead."""

    def __init__(self, candles: Sequence[Candle], timeframe: str) -> None:
        self.candles = candles
        self.delta = pd.Timedelta(seconds=TIMEFRAME_SECONDS[timeframe])
        self._closes = [c.ts + self.delta for c in candles]

    def index_asof(self, ts: pd.Timestamp) -> Optional[int]:
        i = bisect_right(self._closes, ts) - 1
        return i if i >= 0 else None
