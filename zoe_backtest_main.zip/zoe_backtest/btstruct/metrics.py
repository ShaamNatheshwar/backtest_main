"""Turn a list of trades into the numbers that answer "is this profitable, and how reliable is it"."""

from __future__ import annotations

from dataclasses import dataclass
from typing import List

from .backtest import Trade


@dataclass
class Summary:
    symbol: str
    config: str
    n_trades: int
    win_rate: float
    profit_factor: float
    expectancy_r: float
    total_r: float
    max_drawdown_r: float
    avg_win_r: float
    avg_loss_r: float
    largest_win_r: float
    largest_loss_r: float
    outcome_counts: dict

    def as_dict(self) -> dict:
        return self.__dict__


def summarize(symbol: str, config: str, trades: List[Trade]) -> Summary:
    if not trades:
        return Summary(symbol, config, 0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, {})
    rs = [t.r_multiple for t in trades]
    wins = [r for r in rs if r > 0]
    losses = [r for r in rs if r <= 0]
    gross_win = sum(wins)
    gross_loss = abs(sum(losses))
    equity, peak, max_dd = 0.0, 0.0, 0.0
    for r in rs:
        equity += r
        peak = max(peak, equity)
        max_dd = max(max_dd, peak - equity)
    outcomes: dict = {}
    for t in trades:
        outcomes[t.outcome] = outcomes.get(t.outcome, 0) + 1
    return Summary(
        symbol=symbol, config=config, n_trades=len(trades), win_rate=len(wins) / len(trades),
        profit_factor=(gross_win / gross_loss) if gross_loss > 0 else float("inf") if gross_win > 0 else 0.0,
        expectancy_r=sum(rs) / len(rs), total_r=sum(rs), max_drawdown_r=max_dd,
        avg_win_r=(sum(wins) / len(wins)) if wins else 0.0, avg_loss_r=(sum(losses) / len(losses)) if losses else 0.0,
        largest_win_r=max(rs), largest_loss_r=min(rs), outcome_counts=outcomes,
    )


def print_summary(s: Summary) -> None:
    print(f"\n{'=' * 64}\n {s.symbol} | {s.config} trade timeframe\n{'=' * 64}")
    if s.n_trades == 0:
        print(" No trades were generated (see 'skipped' reasons above).")
        return
    print(f" Trades            : {s.n_trades}")
    print(f" Win rate          : {s.win_rate * 100:.1f}%")
    pf = "inf" if s.profit_factor == float("inf") else f"{s.profit_factor:.2f}"
    print(f" Profit factor     : {pf}")
    print(f" Expectancy        : {s.expectancy_r:+.3f} R / trade")
    print(f" Total             : {s.total_r:+.2f} R")
    print(f" Max drawdown      : {s.max_drawdown_r:.2f} R")
    print(f" Avg win / loss    : {s.avg_win_r:+.2f} R / {s.avg_loss_r:+.2f} R")
    print(f" Best / worst trade: {s.largest_win_r:+.2f} R / {s.largest_loss_r:+.2f} R")
    print(f" Outcomes          : {s.outcome_counts}")


def equity_curve_png(trades: List[Trade], path: str) -> None:
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    if not trades:
        return
    xs = list(range(1, len(trades) + 1))
    eq, acc = [], 0.0
    for t in trades:
        acc += t.r_multiple
        eq.append(acc)
    fig, ax = plt.subplots(figsize=(9, 4.5), dpi=130)
    ax.plot(xs, eq, color="#3b82f6", linewidth=1.8)
    ax.axhline(0, color="#888", linewidth=0.8)
    ax.set_xlabel("Trade #"); ax.set_ylabel("Cumulative R")
    ax.set_title(f"{trades[0].symbol} - {trades[0].config} - equity curve (in R multiples)")
    ax.grid(alpha=0.25)
    fig.tight_layout()
    fig.savefig(path)
    plt.close(fig)
