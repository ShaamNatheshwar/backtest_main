"""The cascading multi-timeframe strategy, exactly as described, translated into explicit rules.

====================================================================================================
 THIS IS MY READING OF YOUR RULES - CHECK IT CAREFULLY, ESPECIALLY THE PARTS MARKED "ASSUMPTION"
====================================================================================================

Per trading timeframe (one row below = one ``StrategyConfig``):

    trade_tf | confirm_tf | zone_tf | barrier_tfs (above trade_tf)
    ---------+------------+---------+-------------------------------
    5m       | 15s        | 5m      | 15m, 1h, 4h
    15m      | 30s        | 15m     | 1h, 4h
    1h       | 1m         | 1h      | 4h
    4h       | 5m         | 4h      | (none above 4h)

Entry
    1. ZOE (zone of entry) = an INTERNAL or EXTERNAL Order Block or Fair Value Gap on ``zone_tf``
       (= the trade_tf itself - "my ZOE are 15 min OB/FVG of 15 minutes").  Price must be touching
       that zone right now, or have touched it within ``touch_window`` confirm_tf candles.
    2. Confirmation, on ``confirm_tf``: either
           (a) a market-structure break (MSB) in the trade direction - by construction this is a
               candle BODY close beyond the level, which is how "a clear MSB rather than a liquidity
               hunt" (a wick-only sweep) is enforced, or
           (b) a completed double-bottom (buy) / double-top (sell) pattern (``patterns.py``).
       If nothing confirms within ``touch_window`` confirm_tf candles of the touch, the zone is
       abandoned for this attempt (it can still be touched and tried again later).
    3. Barrier check: at the moment of confirmation, every timeframe ABOVE trade_tf is scanned for an
       OPPOSING zone (open, i.e. not yet filled/mitigated) within ``barrier_atr`` x ATR(zone_tf) of the
       current price - "what will happen if there is 4h or 1h overlapping 15m".  If one exists, the
       trade is skipped - this is your "barrier" concept from the earlier OB/FVG app, reused here.
    4. ASSUMPTION - your table also says the confirm_tf signal is "affected by" the timeframe ONE TIER
       BELOW trade_tf (1m for a 5m trade, 5m for a 15m trade, etc.), which is hard to reconcile with
       "my ZOE are 15m OB/FVG of 15 minutes" (same tier, not one below).  I have implemented this as an
       OPTIONAL extra confluence filter, OFF by default: when enabled, a trade additionally requires an
       open zone on that lower tier, of the SAME side, overlapping price at confirmation time.
       Toggle with ``StrategyConfig.require_lower_tier_confluence``.
    5. One open trade at a time per (instrument, config) - no pyramiding. ASSUMPTION.

Stop-loss ("it will always be that 5 second")
    The most recent CONFIRMED swing low (buy) / high (sell) on the 5-SECOND chart strictly before entry
    (plain fractal: a candle whose low/high is the most extreme of itself and its immediate neighbour on
    each side - i.e. the "small LL/LH/HH/HL" you described), with a small buffer
    (``sl_buffer_atr`` x ATR(5s), ASSUMPTION for how much room to give it).  No usable swing -> no trade.

Exit
    First of, walking forward on 5-SECOND bars from entry:
        * stop-loss hit (wick is enough - a stop is a resting order), or
        * take-profit hit (see below), or
        * a 5s candle BODY closes back through the ZOE zone - "exit when body is formed behind the
          zone" - checked even before the hard stop is reached, or
        * ``max_hold_bars`` 5s candles pass with no decision (timeout; ASSUMPTION, a safety valve).

Take-profit - NOT SPECIFIED IN YOUR MESSAGE. ASSUMPTION, two selectable modes:
    * "next_zone" (default): the nearest OPEN opposing zone on zone_tf beyond entry, capped at
      ``tp_cap_atr`` x ATR; if none exists within the cap, falls back to a fixed R-multiple.
    * "fixed_rr": always ``fallback_rr`` x the stop-loss distance (a plain, fixed reward:risk).
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import List, Optional

TIER_ORDER = ["1m", "5m", "15m", "1h", "4h"]      # low -> high, used to compute "every TF above"


@dataclass(frozen=True)
class StrategyConfig:
    name: str
    trade_tf: str          # = zone_tf
    confirm_tf: str
    lower_tier_tf: Optional[str]
    barrier_tfs: List[str]
    sl_tf: str = "5s"
    touch_window: int = 20            # confirm_tf candles a zone touch stays "live" for (see point 2 above)
    barrier_atr: float = 2.0          # opposing higher-TF zone within this many zone_tf-ATRs blocks entry
    sl_buffer_atr: float = 0.15       # stop placed this many 5s-ATRs beyond the swing point
    min_risk_pct: float = 0.0         # NOT in your rules - an optional guard. A 5s swing can sit a few
                                      # points from entry on a $90k BTC print, producing a "260R" trade
                                      # that single-handedly dominates every statistic (this happened in
                                      # testing). Set e.g. 0.05 to require >=0.05% of price as the stop
                                      # distance; 0 (default) applies no floor, i.e. your rules literally.
    tp_mode: str = "next_zone"        # "next_zone" | "fixed_rr"
    tp_cap_atr: float = 6.0
    fallback_rr: float = 2.0
    max_hold_bars: int = 4000         # 5s candles (~5.5h); safety valve, see "Exit" above
    require_lower_tier_confluence: bool = False
    double_pattern_tol_atr: float = 0.15
    double_pattern_k: int = 2


CONFIGS = {
    "5m": StrategyConfig("5m", "5m", "15s", lower_tier_tf="1m", barrier_tfs=["15m", "1h", "4h"]),
    "15m": StrategyConfig("15m", "15m", "30s", lower_tier_tf="5m", barrier_tfs=["1h", "4h"]),
    "1h": StrategyConfig("1h", "1h", "1m", lower_tier_tf="15m", barrier_tfs=["4h"]),
    "4h": StrategyConfig("4h", "4h", "5m", lower_tier_tf="1h", barrier_tfs=[]),
}

ALL_TIMEFRAMES_NEEDED = sorted({tf for cfg in CONFIGS.values()
                                for tf in [cfg.trade_tf, cfg.confirm_tf, cfg.sl_tf, cfg.lower_tier_tf, *cfg.barrier_tfs]
                                if tf}, key=lambda t: {"5s": 0, "15s": 1, "30s": 2, "1m": 3, "5m": 4,
                                                       "15m": 5, "1h": 6, "4h": 7}[t])
