from __future__ import annotations

from typing import List, Sequence

from .models import Candle


def atr(candles: Sequence[Candle], period: int = 14) -> List[float]:
    trs: List[float] = []
    out: List[float] = []
    for i, c in enumerate(candles):
        prev = candles[i - 1].close if i else c.open
        trs.append(max(c.high - c.low, abs(c.high - prev), abs(c.low - prev)))
        window = trs[-period:]
        out.append(sum(window) / len(window))
    return out
