"""Fair Value Gap detection + internal/external scope tagging (unchanged rules from earlier builds)."""

from __future__ import annotations

from dataclasses import replace
from typing import List, Sequence

from .models import Candle, FairValueGap, FVGStatus, Scope, StructureEvent, Trend


def detect_fvgs(candles: Sequence[Candle], *, fill_on_close: bool = False,
                include_filled: bool = False) -> List[FairValueGap]:
    n = len(candles)
    found: List[FairValueGap] = []
    for i in range(2, n):
        c1, c3 = candles[i - 2], candles[i]
        if c1.high < c3.low:
            direction, bottom, top = Trend.BULLISH, c1.high, c3.low
        elif c1.low > c3.high:
            direction, bottom, top = Trend.BEARISH, c3.high, c1.low
        else:
            continue
        cur_top, cur_bottom, status, filled_at = top, bottom, FVGStatus.FORMED, None
        for j in range(i + 1, n):
            c = candles[j]
            if direction is Trend.BULLISH:
                probe = c.close if fill_on_close else c.low
                if probe <= bottom:
                    status, filled_at = FVGStatus.FILLED, j; break
                cur_top = min(cur_top, max(c.low, bottom))
            else:
                probe = c.close if fill_on_close else c.high
                if probe >= top:
                    status, filled_at = FVGStatus.FILLED, j; break
                cur_bottom = max(cur_bottom, min(c.high, top))
        if status is FVGStatus.FILLED and not include_filled:
            continue
        found.append(FairValueGap(direction, cur_top, cur_bottom, top, bottom, i - 2, i, status, filled_at))
    return found


def classify_fvg_scopes(fvgs: Sequence[FairValueGap], events: Sequence[StructureEvent]) -> List[FairValueGap]:
    legs = [(e.swing_index, e.index, e.scope) for e in events if e.swing_index is not None]
    out = []
    for g in fvgs:
        mid = g.index - 1
        scopes = {sc for lo, hi, sc in legs if lo <= mid <= hi}
        scope = Scope.EXTERNAL if Scope.EXTERNAL in scopes else Scope.INTERNAL if scopes else None
        out.append(replace(g, scope=scope))
    return out
