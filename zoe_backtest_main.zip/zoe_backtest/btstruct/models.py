"""Shared data types."""

from __future__ import annotations

import enum
from dataclasses import dataclass, field
from typing import List, Optional

import pandas as pd


class Trend(enum.Enum):
    BULLISH = 1
    BEARISH = -1

    @property
    def opposite(self) -> "Trend":
        return Trend.BEARISH if self is Trend.BULLISH else Trend.BULLISH


class PivotKind(enum.Enum):
    HH = "HH"; HL = "HL"; LH = "LH"; LL = "LL"

    @property
    def is_high(self) -> bool:
        return self in (PivotKind.HH, PivotKind.LH)


class BreakKind(enum.Enum):
    BOS = "BOS"   # break inside a trend (pullback validated)       -> INTERNAL
    MSB = "MSB"   # market-structure break / trend change           -> EXTERNAL


class Scope(enum.Enum):
    EXTERNAL = "external"
    INTERNAL = "internal"


class FVGStatus(enum.Enum):
    FORMING = "forming"; FORMED = "formed"; FILLED = "filled"


class OBStatus(enum.Enum):
    ACTIVE = "active"; MITIGATED = "mitigated"


@dataclass(frozen=True)
class Candle:
    ts: pd.Timestamp
    open: float
    high: float
    low: float
    close: float
    volume: float = 0.0

    @property
    def is_bullish(self) -> bool:
        return self.close >= self.open


@dataclass(frozen=True)
class Pivot:
    kind: PivotKind
    index: int
    price: float
    confirmed_at: int
    scope: Scope = Scope.EXTERNAL


@dataclass(frozen=True)
class StructureEvent:
    kind: BreakKind
    direction: Trend
    level: float
    origin_index: int
    index: int               # candle whose BODY closed beyond the level (the MSB/BOS candle)
    scope: Scope = Scope.EXTERNAL
    swing_index: Optional[int] = None


@dataclass(frozen=True)
class FairValueGap:
    direction: Trend
    top: float
    bottom: float
    orig_top: float
    orig_bottom: float
    start_index: int
    index: int
    status: FVGStatus
    filled_index: Optional[int] = None
    scope: Optional[Scope] = None


@dataclass(frozen=True)
class OrderBlock:
    direction: Trend
    top: float
    bottom: float
    index: int
    break_index: int
    scope: Scope
    status: OBStatus
    mitigated_index: Optional[int] = None


@dataclass
class StructureResult:
    candles: List[Candle]
    pivots: List[Pivot] = field(default_factory=list)
    events: List[StructureEvent] = field(default_factory=list)
    trend: Optional[Trend] = None
    protected_index: Optional[int] = None
    protected_level: Optional[float] = None

    def pivots_by_scope(self, scope: Scope) -> List[Pivot]:
        return [p for p in self.pivots if p.scope is scope]
