"""The backtest event loop: walks the confirm_tf candle by candle, looks for a ZOE touch + confirmation
+ barrier check, and - on entry - simulates the trade to its conclusion on 5-second bars.  See
``strategy.py`` for the exact rules and the assumptions I had to make.
"""

from __future__ import annotations

from collections import Counter
from dataclasses import dataclass
from typing import Dict, List, Optional

import pandas as pd

from .bars import TIMEFRAME_SECONDS, AsOfIndex
from .engine import analyze_structure
from .indicators import atr as atr_series
from .models import BreakKind, Candle, Trend
from .patterns import detect_double_patterns, last_swing_before
from .strategy import StrategyConfig
from .zones import Zone, build_zones


@dataclass
class Trade:
    symbol: str
    config: str
    direction: str             # "BUY" | "SELL"
    signal_kind: str           # "MSB" | "double_bottom" | "double_top"
    zone_kind: str             # "OB" | "FVG"
    zone_scope: str            # "internal" | "external"
    entry_ts: pd.Timestamp
    entry_price: float
    sl_price: float
    tp_price: float
    exit_ts: pd.Timestamp
    exit_price: float
    outcome: str               # "tp" | "sl" | "zone_invalidated" | "timeout" | "timeout_no_data"
    r_multiple: float
    risk_points: float


@dataclass
class BacktestResult:
    symbol: str
    config: str
    trades: List[Trade]
    skipped: Counter
    candle_counts: Dict[str, int]


def _simulate_exit(sl_candles, start_idx: int, direction: Trend, sl_price: float, tp_price: float,
                   zone: Zone, max_hold: int, sl_delta: pd.Timedelta):
    """Exit timestamps are the CLOSE of the deciding 5s candle - we only know a stop/target was hit, or
    that a candle's body closed through the zone, once that candle has actually finished forming."""
    bull = direction is Trend.BULLISH
    end = min(len(sl_candles), start_idx + max_hold)
    for j in range(start_idx, end):
        c = sl_candles[j]
        hit_sl = c.low <= sl_price if bull else c.high >= sl_price
        hit_tp = c.high >= tp_price if bull else c.low <= tp_price
        if hit_sl:                              # ASSUMPTION: if both hit in the same 5s candle, SL wins
            return j, c.ts + sl_delta, sl_price, "sl"   # (cannot know the intrabar order without real ticks here)
        if hit_tp:
            return j, c.ts + sl_delta, tp_price, "tp"
        invalidated = c.close < zone.bottom if bull else c.close > zone.top
        if invalidated:
            return j, c.ts + sl_delta, c.close, "zone_invalidated"
    j = min(end, len(sl_candles)) - 1
    if j < start_idx:
        j = min(start_idx, len(sl_candles) - 1)
    return j, sl_candles[j].ts + sl_delta, sl_candles[j].close, "timeout"


def run_backtest(symbol: str, bars_by_tf: Dict[str, List[Candle]], cfg: StrategyConfig) -> BacktestResult:
    trade_candles = bars_by_tf[cfg.trade_tf]
    confirm_candles = bars_by_tf[cfg.confirm_tf]
    sl_candles = bars_by_tf[cfg.sl_tf]
    skipped: Counter = Counter()
    if len(trade_candles) < 20 or len(confirm_candles) < 20 or len(sl_candles) < 20:
        return BacktestResult(symbol, cfg.name, [], Counter({"insufficient_data": 1}),
                              {tf: len(cs) for tf, cs in bars_by_tf.items()})

    trade_structure = analyze_structure(trade_candles)
    confirm_structure = analyze_structure(confirm_candles)
    zone_list = build_zones(cfg.trade_tf, trade_candles, trade_structure)
    double_signals = detect_double_patterns(confirm_candles, k=cfg.double_pattern_k,
                                            tol_atr=cfg.double_pattern_tol_atr)
    double_by_index: Dict[int, object] = {}
    for s in double_signals:
        double_by_index.setdefault(s.confirm_index, s)
    msb_by_index = {e.index: e for e in confirm_structure.events if e.kind is BreakKind.MSB}

    barrier_zones = {tf: build_zones(tf, bars_by_tf[tf]) for tf in cfg.barrier_tfs if tf in bars_by_tf}
    lower_zones = (build_zones(cfg.lower_tier_tf, bars_by_tf[cfg.lower_tier_tf])
                  if cfg.require_lower_tier_confluence and cfg.lower_tier_tf in bars_by_tf else None)

    trade_asof = AsOfIndex(trade_candles, cfg.trade_tf)
    sl_asof = AsOfIndex(sl_candles, cfg.sl_tf)
    trade_atr = atr_series(trade_candles)
    confirm_delta = pd.Timedelta(seconds=TIMEFRAME_SECONDS[cfg.confirm_tf])
    sl_delta = pd.Timedelta(seconds=TIMEFRAME_SECONDS[cfg.sl_tf])

    last_touch: Dict[int, int] = {}
    trades: List[Trade] = []
    blocked_until: Optional[pd.Timestamp] = None

    for i, cc in enumerate(confirm_candles):
        decision_ts = cc.ts + confirm_delta    # the confirm candle only "closes" (becomes knowable) here
        for zi, z in enumerate(zone_list):
            if z.active_at(decision_ts) and z.overlaps(cc.low, cc.high):
                last_touch[zi] = i

        if blocked_until is not None and decision_ts < blocked_until:
            continue

        direction = kind = None
        if i in msb_by_index:
            direction, kind = msb_by_index[i].direction, "MSB"
        elif i in double_by_index:
            s = double_by_index[i]
            direction, kind = s.direction, s.kind
        if direction is None:
            continue

        matching = [(zi, z) for zi, z in enumerate(zone_list)
                   if z.direction is direction and z.active_at(decision_ts) and i - last_touch.get(zi, -10**9) <= cfg.touch_window]
        if not matching:
            skipped["no_recent_zone_touch"] += 1
            continue
        zi, zone = min(matching, key=lambda zi_z: abs(zi_z[1].distance(cc.close)))

        ti = trade_asof.index_asof(decision_ts)
        atr_now = trade_atr[ti] if ti is not None else 0.0
        blocked = False
        for tf, zlist in barrier_zones.items():
            for z2 in zlist:
                if z2.direction is direction.opposite and z2.active_at(decision_ts) and abs(z2.distance(cc.close)) <= cfg.barrier_atr * atr_now:
                    blocked = True
                    break
            if blocked:
                break
        if blocked:
            skipped["barrier_zone_above"] += 1
            continue

        if cfg.require_lower_tier_confluence:
            ok = any(z3.direction is direction and z3.active_at(decision_ts) and z3.overlaps(cc.low, cc.high) for z3 in lower_zones)
            if not ok:
                skipped["no_lower_tier_confluence"] += 1
                continue

        sl_idx = sl_asof.index_asof(decision_ts)
        if sl_idx is None:
            skipped["no_5s_data_yet"] += 1
            continue
        swing = last_swing_before(sl_candles, sl_idx + 1, want_low=(direction is Trend.BULLISH), k=1)
        if swing is None:
            skipped["no_5s_swing_point"] += 1
            continue
        sl_atr = atr_series(sl_candles[max(0, swing.index - 20): swing.index + 1])
        buffer_pts = cfg.sl_buffer_atr * (sl_atr[-1] if sl_atr else 0.0)
        bull = direction is Trend.BULLISH
        entry_ts, entry_price = decision_ts, cc.close
        sl_price = swing.price - buffer_pts if bull else swing.price + buffer_pts
        risk = abs(entry_price - sl_price)
        if risk <= 0:
            skipped["zero_risk"] += 1
            continue
        if cfg.min_risk_pct > 0 and risk < cfg.min_risk_pct / 100.0 * entry_price:
            skipped["risk_below_floor"] += 1
            continue

        tp_price = None
        if cfg.tp_mode == "next_zone":
            opposing = [z for z in zone_list if z.direction is direction.opposite and z.active_at(decision_ts)
                       and ((z.bottom > entry_price) if bull else (z.top < entry_price))]
            if opposing:
                nearest = min(opposing, key=lambda z: abs(z.distance(entry_price)))
                cand = nearest.bottom if bull else nearest.top
                if abs(cand - entry_price) <= cfg.tp_cap_atr * atr_now:
                    tp_price = cand
        if tp_price is None:
            tp_price = entry_price + cfg.fallback_rr * risk if bull else entry_price - cfg.fallback_rr * risk

        exit_idx, exit_ts, exit_price, outcome = _simulate_exit(
            sl_candles, sl_idx + 1, direction, sl_price, tp_price, zone, cfg.max_hold_bars, sl_delta)
        r_multiple = ((exit_price - entry_price) / risk) if bull else ((entry_price - exit_price) / risk)
        trades.append(Trade(symbol, cfg.name, "BUY" if bull else "SELL", kind, zone.kind, zone.scope.value,
                            entry_ts, entry_price, sl_price, tp_price, exit_ts, exit_price, outcome, r_multiple, risk))
        blocked_until = exit_ts

    return BacktestResult(symbol, cfg.name, trades, skipped, {tf: len(cs) for tf, cs in bars_by_tf.items()})
