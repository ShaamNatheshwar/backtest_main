"""Order-block detection (unchanged rules from earlier builds): the last opposite-coloured candle
before the move that broke structure. BOS -> internal OB, MSB -> external OB."""

from __future__ import annotations

from typing import List, Sequence, Set, Tuple

from .models import Candle, OBStatus, OrderBlock, StructureResult, Trend

OB_LOOKBACK = 5


def pick_ob_candle(candles: Sequence[Candle], swing: int, floor: int, direction: Trend,
                   lookback: int = OB_LOOKBACK) -> int:
    want_down = direction is Trend.BULLISH
    lowest = max(min(floor, swing), swing - lookback + 1, 0)
    for j in range(swing, lowest - 1, -1):
        c = candles[j]
        if c.close != c.open and (c.close < c.open) == want_down:
            return j
    return swing


def detect_order_blocks(result: StructureResult, *, include_mitigated: bool = False) -> List[OrderBlock]:
    cs = result.candles
    seen: Set[Tuple[Trend, int]] = set()
    out: List[OrderBlock] = []
    for e in sorted(result.events, key=lambda ev: (ev.index, ev.origin_index)):
        if e.swing_index is None:
            continue
        swing = min(e.swing_index, e.index - 1)
        j = pick_ob_candle(cs, swing, e.origin_index + 1, e.direction)
        if (e.direction, j) in seen:
            continue
        seen.add((e.direction, j))
        bull = e.direction is Trend.BULLISH
        top, bottom = cs[j].high, cs[j].low
        status, mitigated_at = OBStatus.ACTIVE, None
        for k in range(e.index + 1, len(cs)):
            c = cs[k]
            if (c.close < bottom) if bull else (c.close > top):
                status, mitigated_at = OBStatus.MITIGATED, k
                break
        if status is OBStatus.MITIGATED and not include_mitigated:
            continue
        out.append(OrderBlock(e.direction, top, bottom, j, e.index, e.scope, status, mitigated_at))
    return sorted(out, key=lambda b: (b.index, b.break_index))
