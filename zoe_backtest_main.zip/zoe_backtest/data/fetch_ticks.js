#!/usr/bin/env node
/**
 * Downloads REAL tick data from Dukascopy via dukascopy-node and writes it to a CSV that
 * synthetic_ticks.py's format matches (timestamp epoch-ms, bidPrice, askPrice, bidVolume, askVolume),
 * so run_backtest.py reads either one identically.
 *
 * Run this on YOUR machine (this sandbox cannot reach the npm registry or Dukascopy's servers - both
 * return HTTP 403 here).
 *
 *   npm install dukascopy-node
 *   node fetch_ticks.js --instrument btcusd --from 2025-09-01 --to 2025-09-08 --out btcusd_ticks.csv
 *   node fetch_ticks.js --instrument xauusd --from 2025-09-01 --to 2025-09-08 --out xauusd_ticks.csv
 *
 * Tick data for a week can already be tens of millions of rows for an active instrument - start with a
 * short range (a few days) to make sure the rest of the pipeline works before requesting more.
 * Fetches one day at a time and appends to the CSV, so a dropped connection only costs you one day
 * and you can re-run with --from set to the day that failed.
 */
const fs = require('fs');
const { getHistoricalRates } = require('dukascopy-node');

function parseArgs() {
  const out = { instrument: 'btcusd', from: null, to: null, out: 'ticks.csv', batchSize: 5, pauseMs: 1500 };
  const argv = process.argv.slice(2);
  for (let i = 0; i < argv.length; i += 2) {
    const key = argv[i].replace(/^--/, '');
    out[key] = argv[i + 1];
  }
  if (!out.from || !out.to) throw new Error('Usage: node fetch_ticks.js --instrument btcusd --from 2025-09-01 --to 2025-09-08 --out ticks.csv');
  return out;
}

function* dayRanges(from, to) {
  let d = new Date(from + 'T00:00:00Z');
  const end = new Date(to + 'T00:00:00Z');
  while (d < end) {
    const next = new Date(d.getTime() + 86400000);
    yield [new Date(d), next < end ? next : end];
    d = next;
  }
}

(async () => {
  const args = parseArgs();
  const stream = fs.createWriteStream(args.out, { flags: 'w' });
  stream.write('timestamp,bidPrice,askPrice,bidVolume,askVolume\n');
  let total = 0;

  for (const [from, to] of dayRanges(args.from, args.to)) {
    process.stdout.write(`Fetching ${args.instrument} ${from.toISOString().slice(0, 10)} ... `);
    try {
      const ticks = await getHistoricalRates({
        instrument: args.instrument,
        dates: { from, to },
        timeframe: 'tick',
        format: 'json',
        batchSize: Number(args.batchSize),
        pauseBetweenBatchesMs: Number(args.pauseMs),
      });
      for (const t of ticks) {
        stream.write(`${t.timestamp},${t.bidPrice},${t.askPrice},${t.bidVolume ?? 0},${t.askVolume ?? 0}\n`);
      }
      total += ticks.length;
      console.log(`${ticks.length.toLocaleString()} ticks (running total: ${total.toLocaleString()})`);
    } catch (err) {
      console.log(`FAILED: ${err.message}`);
      console.log(`Re-run with --from ${from.toISOString().slice(0, 10)} to resume from here.`);
      break;
    }
  }
  stream.end();
  console.log(`\nWrote ${total.toLocaleString()} ticks to ${args.out}`);
})();
