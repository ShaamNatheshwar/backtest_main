#!/usr/bin/env python3
"""Generates a SYNTHETIC tick stream - for exercising the backtest end-to-end only.

This is NOT real market data and the results it produces prove nothing about real profitability.
It exists because this sandbox cannot reach Dukascopy's servers or the npm registry (both return
HTTP 403) to run ``fetch_ticks.js`` for you. Use ``fetch_ticks.js`` for the real thing.

Usage
    python synthetic_ticks.py --symbol BTCUSD --days 6 --out btcusd_ticks.csv
    python synthetic_ticks.py --symbol XAUUSD --days 6 --out xauusd_ticks.csv
"""

from __future__ import annotations

import argparse
import random

import numpy as np
import pandas as pd

PROFILES = {
    "BTCUSD": {"price": 95_000.0, "spread": 8.0, "tick_vol": 6.0, "mean_gap_s": 1.5},
    "XAUUSD": {"price": 2_650.0, "spread": 0.35, "tick_vol": 0.22, "mean_gap_s": 2.5},
}


def generate(symbol: str, days: int, seed: int = 7) -> pd.DataFrame:
    prof = PROFILES.get(symbol.upper(), {"price": 1000.0, "spread": 1.0, "tick_vol": 0.5, "mean_gap_s": 2.0})
    rnd = random.Random(seed)
    np_rng = np.random.default_rng(seed)

    start = pd.Timestamp.now(tz="UTC").floor("D") - pd.Timedelta(days=days)
    n_est = int(days * 86400 / prof["mean_gap_s"] * 1.05)
    gaps = np_rng.exponential(prof["mean_gap_s"], size=n_est)
    ts = start + pd.to_timedelta(np.cumsum(gaps), unit="s")
    ts = ts[ts < start + pd.Timedelta(days=days)]
    n = len(ts)

    mid = np.empty(n)
    px = prof["price"]
    drift = 0.0
    left = 0
    for i in range(n):
        if left <= 0:
            drift = rnd.choice([-0.08, -0.03, 0.0, 0.03, 0.08]) * prof["tick_vol"]
            left = rnd.randint(400, 1400)       # regime length, in ticks
        left -= 1
        px += np_rng.normal(drift, prof["tick_vol"])
        mid[i] = px

    half = prof["spread"] / 2.0
    bid = mid - half
    ask = mid + half
    vol = np_rng.uniform(0.01, 1.5, size=n)
    return pd.DataFrame({"timestamp": (ts.view("int64") // 10**6), "bidPrice": bid, "askPrice": ask,
                        "bidVolume": vol, "askVolume": vol * np_rng.uniform(0.8, 1.2, size=n)})


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--symbol", default="BTCUSD", choices=list(PROFILES))
    ap.add_argument("--days", type=int, default=6)
    ap.add_argument("--seed", type=int, default=7)
    ap.add_argument("--out", required=True)
    args = ap.parse_args()
    df = generate(args.symbol, args.days, args.seed)
    df.to_csv(args.out, index=False)
    print(f"Wrote {len(df):,} synthetic ticks for {args.symbol} ({args.days} days) -> {args.out}")


if __name__ == "__main__":
    main()
